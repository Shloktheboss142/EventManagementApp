package com.fit2081.assignment1;

public class KeyStore {
    public static String FILE_NAME = "UNIQUE_FILE_NAME";
    public static String USERNAME = "USERNAME";
    public static String PASSWORD = "PASSWORD";
    public static String NEW_CATEGORY_CATEGORY_ID = "NEW_CATEGORY_CATEGORY_ID";
    public static String NEW_CATEGORY_CATEGORY_NAME = "NEW_CATEGORY_CATEGORY_NAME";
    public static String NEW_CATEGORY_EVENT_COUNT = "NEW_CATEGORY_EVENT_COUNT";
    public static String NEW_CATEGORY_IS_ACTIVE = "NEW_CATEGORY_IS_ACTIVE";
    public static String NEW_EVENT_EVENT_ID = "NEW_EVENT_EVENT_ID";
    public static String NEW_EVENT_EVENT_NAME = "NEW_EVENT_EVENT_NAME";
    public static String NEW_EVENT_CATEGORY_ID = "NEW_EVENT_CATEGORY_ID";
    public static String NEW_EVENT_TICKETS_AVAILABLE = "NEW_EVENT_TICKETS_AVAILABLE";
    public static String NEW_EVENT_IS_ACTIVE = "NEW_EVENT_IS_ACTIVE";
    public static String ALL_EVENT_CATEGORIES = "ALL_EVENT_CATEGORIES";
    public static String ALL_EVENTS = "ALL_EVENTS";
}
